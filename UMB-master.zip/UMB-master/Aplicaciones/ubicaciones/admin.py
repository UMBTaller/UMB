from django.contrib import admin
from .models import Lugares

# Register your models here.
admin.site.register(Lugares)